#RequireAdmin
#include <GUIConstantsEx.au3>
#include <MsgBoxConstants.au3>
#include <StaticConstants.au3>

; Create main GUI
Local $hGUI = GUICreate("Network Sharing Registry Editor", 580, 520)
GUISetFont(9, 400, 0, "Segoe UI")
GUICtrlCreateLabel("Enable classic Windows network sharing features (XP-style, INSECURE on untrusted networks).", 20, 10, 540, 30)

; Checkboxes for each setting
Local $idChk1 = GUICtrlCreateCheckbox("Allow BLANK passwords for network access (Lsa LimitBlankPasswordUse=0)", 20, 50, 540, 20)
Local $idChk3 = GUICtrlCreateCheckbox("Enable legacy SMB1/2 SERVER (LanmanServer SMB1/SMB2 = 1)", 20, 75, 540, 20)
Local $idChk4 = GUICtrlCreateCheckbox("RELAX SMB security signatures (LanmanWorkstation Require/EnableSecuritySignature=0)", 20, 100, 540, 35)
Local $idChk5 = GUICtrlCreateCheckbox("Enable full LOCAL ADMIN tokens over network (LocalAccountTokenFilterPolicy=1)", 20, 135, 540, 20)
Local $idChk6 = GUICtrlCreateCheckbox("Enable firewall FILE AND PRINTER SHARING (all profiles)", 20, 165, 540, 20)
Local $idChk7 = GUICtrlCreateCheckbox("Enable firewall NETWORK DISCOVERY (all profiles)", 20, 190, 540, 20)

; Buttons
Local $idBtnApply = GUICtrlCreateButton("Apply Selected Changes", 20, 390, 170, 35)
Local $idBtnReset = GUICtrlCreateButton("Reset All to Windows Defaults", 205, 390, 190, 35)
Local $idBtnLoad  = GUICtrlCreateButton("Reload Current Settings", 410, 390, 150, 35)
Local $idBtnXP    = GUICtrlCreateButton("Apply XP-Style Sharing Preset", 20, 430, 540, 35)

; Status label
Local $idStatus = GUICtrlCreateLabel("Ready. Run as Administrator.", 20, 345, 540, 25, $SS_SUNKEN + $SS_CENTER)

GUISetState(@SW_SHOW)

; Load current registry state on startup
_LoadCurrentSettings()

; Main loop
While 1
    Switch GUIGetMsg()
        Case $GUI_EVENT_CLOSE
            Exit
        Case $idBtnApply
            _ApplyChanges()
        Case $idBtnReset
            _ResetToDefaults()
        Case $idBtnLoad
            _LoadCurrentSettings()
        Case $idBtnXP
            _ApplyXPPreset()
    EndSwitch
WEnd

; --- Helper: read DWORD safely (returns default if missing) ---
Func _RegReadDWordDefault($sKey, $sValue, $iDefault)
    Local $v = RegRead($sKey, $sValue)
    If @error Then Return $iDefault
    Return $v
EndFunc

; Check if a firewall rule group is enabled (rough heuristic)
Func _CheckFirewallGroupEnabled($sGroup)
    ; Checks for any enabled rule in the group name output
    Local $sCmd = 'netsh advfirewall firewall show rule name=all | find /I "' & $sGroup & '" | find /I "Yes"'
    Local $iExit = RunWait(@ComSpec & " /c " & $sCmd, "", @SW_HIDE)
    Return ($iExit = 0)
EndFunc

; Load checkboxes from current registry/OS values
Func _LoadCurrentSettings()
    ; 1. Blank password limit (0 = allow blank)
    Local $iVal = _RegReadDWordDefault("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa", "LimitBlankPasswordUse", 1)
    GUICtrlSetState($idChk1, ($iVal = 0) ? $GUI_CHECKED : $GUI_UNCHECKED)

    ; 3. SMB1 and SMB2 (1=enabled, default if missing)
    Local $iSMB1 = _RegReadDWordDefault("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanServer\\Parameters", "SMB1", 1)
    Local $iSMB2 = _RegReadDWordDefault("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanServer\\Parameters", "SMB2", 1)
    GUICtrlSetState($idChk3, (($iSMB1 = 1) And ($iSMB2 = 1)) ? $GUI_CHECKED : $GUI_UNCHECKED)

    ; 4. Require/EnableSecuritySignature (0=disabled)
    Local $iSigReq = _RegReadDWordDefault("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanWorkstation\\Parameters", "RequireSecuritySignature", 1)
    Local $iSigEn  = _RegReadDWordDefault("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanWorkstation\\Parameters", "EnableSecuritySignature", 1)
    GUICtrlSetState($idChk4, (($iSigReq = 0) And ($iSigEn = 0)) ? $GUI_CHECKED : $GUI_UNCHECKED)

    ; 5. LocalAccountTokenFilterPolicy (1=enabled)
    Local $iToken = _RegReadDWordDefault("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", "LocalAccountTokenFilterPolicy", 0)
    GUICtrlSetState($idChk5, ($iToken = 1) ? $GUI_CHECKED : $GUI_UNCHECKED)

    ; 6. Firewall: File and Printer Sharing
    Local $bFPS = _CheckFirewallGroupEnabled("File and Printer Sharing")
    GUICtrlSetState($idChk6, $bFPS ? $GUI_CHECKED : $GUI_UNCHECKED)

    ; 7. Firewall: Network Discovery
    Local $bND = _CheckFirewallGroupEnabled("Network Discovery")
    GUICtrlSetState($idChk7, $bND ? $GUI_CHECKED : $GUI_UNCHECKED)

    GUICtrlSetData($idStatus, "Current settings loaded.")
EndFunc

; Apply only checked settings
Func _ApplyChanges()
    Local $iChanges = 0, $sMsg = "Applied: "

    ; 1. Blank passwords
    If GUICtrlRead($idChk1) = $GUI_CHECKED Then
        RegWrite("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa", "LimitBlankPasswordUse", "REG_DWORD", 0)
        $sMsg &= "Blank passwords; "
        $iChanges += 1
    EndIf

    ; 3. SMB1/2 server
    If GUICtrlRead($idChk3) = $GUI_CHECKED Then
        RegWrite("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanServer\\Parameters", "SMB1", "REG_DWORD", 1)
        RegWrite("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanServer\\Parameters", "SMB2", "REG_DWORD", 1)
        $sMsg &= "SMB1/2 server; "
        $iChanges += 1
    EndIf

    ; 4. Relax SMB signatures
    If GUICtrlRead($idChk4) = $GUI_CHECKED Then
        RegWrite("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanWorkstation\\Parameters", "RequireSecuritySignature", "REG_DWORD", 0)
        RegWrite("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanWorkstation\\Parameters", "EnableSecuritySignature", "REG_DWORD", 0)
        $sMsg &= "SMB signatures relaxed; "
        $iChanges += 1
    EndIf

    ; 5. LocalAccountTokenFilterPolicy
    If GUICtrlRead($idChk5) = $GUI_CHECKED Then
        RegWrite("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", "LocalAccountTokenFilterPolicy", "REG_DWORD", 1)
        $sMsg &= "Full local admin tokens; "
        $iChanges += 1
    EndIf

    ; 6. Firewall File and Printer Sharing
    If GUICtrlRead($idChk6) = $GUI_CHECKED Then
        RunWait(@ComSpec & ' /c netsh advfirewall firewall set rule group="File and Printer Sharing" new enable=Yes', "", @SW_HIDE)
        $sMsg &= "Firewall FPS; "
        $iChanges += 1
    EndIf

    ; 7. Firewall Network Discovery
    If GUICtrlRead($idChk7) = $GUI_CHECKED Then
        RunWait(@ComSpec & ' /c netsh advfirewall firewall set rule group="Network Discovery" new enable=Yes', "", @SW_HIDE)
        $sMsg &= "Firewall ND; "
        $iChanges += 1
    EndIf

    If $iChanges > 0 Then
        GUICtrlSetData($idStatus, $sMsg & "Reboot recommended.")
        _LoadCurrentSettings()
        MsgBox($MB_ICONINFORMATION, "Success", $iChanges & " change(s) applied successfully!" & @CRLF & _
               "WARNING: These settings are XP-style and very insecure on untrusted networks.")
    Else
        GUICtrlSetData($idStatus, "No checkboxes selected.")
    EndIf
EndFunc

; XP-style preset: tick everything "classic sharing" and apply
Func _ApplyXPPreset()
    ; Tick all the core "loosen everything" options
    GUICtrlSetState($idChk1, $GUI_CHECKED) ; blank passwords
    GUICtrlSetState($idChk3, $GUI_CHECKED) ; SMB1/2 server
    GUICtrlSetState($idChk4, $GUI_CHECKED) ; relax SMB signatures
    GUICtrlSetState($idChk5, $GUI_CHECKED) ; full local admin tokens
    GUICtrlSetState($idChk6, $GUI_CHECKED) ; firewall file/print sharing
    GUICtrlSetState($idChk7, $GUI_CHECKED) ; firewall network discovery

    If MsgBox($MB_ICONWARNING + $MB_YESNO, "XP-Style Preset", _
            "This will apply very insecure, XP-era style sharing:" & @CRLF & _
            "- SMB1 + relaxed SMB security" & @CRLF & _
            "- Blank passwords allowed over LAN" & @CRLF & _
            "- Full local admin tokens over network" & @CRLF & _
            "- File/Printer Sharing + Network Discovery firewall groups ON" & @CRLF & _
            @CRLF & "Use ONLY on a trusted, isolated LAN. Continue?") = $IDYES Then

        _ApplyChanges()
    Else
        GUICtrlSetData($idStatus, "XP-style preset cancelled.")
    EndIf
EndFunc

; Reset everything to standard Windows defaults
Func _ResetToDefaults()
    ; Defaults – approximate modern Windows behavior
    RegWrite("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa", "LimitBlankPasswordUse", "REG_DWORD", 1)

    RegWrite("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanServer\\Parameters", "SMB1", "REG_DWORD", 0)
    RegDelete("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanServer\\Parameters", "SMB2")

    RegWrite("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanWorkstation\\Parameters", "RequireSecuritySignature", "REG_DWORD", 1)
    RegWrite("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanWorkstation\\Parameters", "EnableSecuritySignature", "REG_DWORD", 1)

    RegDelete("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", "LocalAccountTokenFilterPolicy")

    ; Firewall: turn both groups off
    RunWait(@ComSpec & ' /c netsh advfirewall firewall set rule group="File and Printer Sharing" new enable=No', "", @SW_HIDE)
    RunWait(@ComSpec & ' /c netsh advfirewall firewall set rule group="Network Discovery" new enable=No', "", @SW_HIDE)

    _LoadCurrentSettings()
    GUICtrlSetData($idStatus, "All reset to Windows defaults (approx). Reboot recommended.")
    MsgBox($MB_ICONINFORMATION, "Reset Complete", "Registry and firewall reset to safer defaults. Reboot recommended.")
EndFunc
